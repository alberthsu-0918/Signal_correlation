var class_c_cross_correlation_c_c =
[
    [ "CCrossCorrelationCC", "class_c_cross_correlation_c_c.html#ae5ad77335763cd00adf0db2e89c8b060", null ],
    [ "~CCrossCorrelationCC", "class_c_cross_correlation_c_c.html#af08f97a1dd2deb3b3008d8e467f14e11", null ],
    [ "ComputeCrossCorrelation", "class_c_cross_correlation_c_c.html#a0a8735f917b12a20155bb070a4cfd5f0", null ],
    [ "ComputeWindowedCrossCorrelationPerTrial", "class_c_cross_correlation_c_c.html#af0485f29d867e91ff688b304310a25c5", null ],
    [ "GetCorrelationWindow", "class_c_cross_correlation_c_c.html#a28b0c30149333cf485553fbf05929f1d", null ],
    [ "GetCrossCorrelogram", "class_c_cross_correlation_c_c.html#a1b8b73208beb10f25b88fe49625c6316", null ],
    [ "GetTrialLength", "class_c_cross_correlation_c_c.html#a8a07e1931474bff219d518c30c3f9608", null ],
    [ "ModifyAllParameters", "class_c_cross_correlation_c_c.html#a69a98628cf5c82476daf20d99e99b35b", null ],
    [ "ModifyCorrelationWindow", "class_c_cross_correlation_c_c.html#a8c6d732a060c3533ad353e65f412bb5f", null ],
    [ "ModifyTrialLength", "class_c_cross_correlation_c_c.html#a9b36a1d2867bdc6f4924b99dc09ff0e3", null ]
];