var class_c_scaled_correlation_c_c =
[
    [ "CScaledCorrelationCC", "class_c_scaled_correlation_c_c.html#a546e366a0092b7779a1bec010dad54af", null ],
    [ "~CScaledCorrelationCC", "class_c_scaled_correlation_c_c.html#ab5842f027665e8ae982778144a6c58fc", null ],
    [ "ComputeScaledCorrelation", "class_c_scaled_correlation_c_c.html#a7fdeee63d7e1d4dde852ab6f32d00dc6", null ],
    [ "ComputeWindowedScaledCorrelationPerTrial", "class_c_scaled_correlation_c_c.html#a005c1ecfe2118892e4c3ae4b25174fd9", null ],
    [ "GetCorrelationWindow", "class_c_scaled_correlation_c_c.html#a5a47fe03d457de8c91b7f95bcc77afe4", null ],
    [ "GetDistributionOfCorrelationCoefficients", "class_c_scaled_correlation_c_c.html#a891cfdbe5d66be5337d3ba2a8175c031", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinNr", "class_c_scaled_correlation_c_c.html#a2d3f368b3328c928e7d0c1e34092de1f", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinSize", "class_c_scaled_correlation_c_c.html#ad2009215e63075b55f386371055374e7", null ],
    [ "GetPearsonCoefficientCounts", "class_c_scaled_correlation_c_c.html#aef784291ddf4f3ae4a439da61cea933f", null ],
    [ "GetPearsonCoefficientSums", "class_c_scaled_correlation_c_c.html#a2bf3a38d0f4a4141019bc25eda7cf7da", null ],
    [ "GetScaledCrossCorrelogram", "class_c_scaled_correlation_c_c.html#a604da735edd12e35788ff1ce5987ffe1", null ],
    [ "GetScaleWindow", "class_c_scaled_correlation_c_c.html#abeabce0826fbe620dad961dc5c936d72", null ],
    [ "GetTrialLength", "class_c_scaled_correlation_c_c.html#a35a65b873916ba3e4c837374c0712cca", null ],
    [ "ModifyAllParameters", "class_c_scaled_correlation_c_c.html#aa58ddb2648adf8952a18601454cd6099", null ],
    [ "ModifyCorrelationWindow", "class_c_scaled_correlation_c_c.html#a96efc584d221bf6bae346e70e8240105", null ],
    [ "ModifyScaleWindow", "class_c_scaled_correlation_c_c.html#a16ce5c8569cf8b87c4ae710e8598201e", null ],
    [ "ModifyTrialLength", "class_c_scaled_correlation_c_c.html#a3bfd567ab737f72bbeafc053f61fd9f2", null ]
];