var class_c_scaled_correlation_b_b =
[
    [ "CScaledCorrelationBB", "class_c_scaled_correlation_b_b.html#a7f65b28073a345819f3b3f06d8df7fe6", null ],
    [ "~CScaledCorrelationBB", "class_c_scaled_correlation_b_b.html#a30d78929a7ffbc0991eb7a4e2f5ea33d", null ],
    [ "ComputeScaledCorrelation", "class_c_scaled_correlation_b_b.html#a6b7cb7c0668ce7e9fcac1b84609a5f1d", null ],
    [ "ComputeWindowedScaledCorrelationPerTrial", "class_c_scaled_correlation_b_b.html#a48f84134333746fbce70f24893afd1b7", null ],
    [ "GetCorrelationWindow", "class_c_scaled_correlation_b_b.html#aa4ff2e0c4e18ebe552e8fa794cba91eb", null ],
    [ "GetDistributionOfCorrelationCoefficients", "class_c_scaled_correlation_b_b.html#a657e82fac3e36e43f180b561b0265ef7", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinNr", "class_c_scaled_correlation_b_b.html#af48079f6975d1d27fc090e06fa3d7b40", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinSize", "class_c_scaled_correlation_b_b.html#ad834271d7485e15bced589d52d7ac31b", null ],
    [ "GetFiCoefficientCounts", "class_c_scaled_correlation_b_b.html#afde44f9c8ea8ca93fb9ba576cfad36ee", null ],
    [ "GetFiCoefficientSums", "class_c_scaled_correlation_b_b.html#aa60c7d7930cb3a1a50d6bfa919857a85", null ],
    [ "GetScaledCrossCorrelogram", "class_c_scaled_correlation_b_b.html#afb27a1ee72603369f7956446e7c59099", null ],
    [ "GetScaleWindow", "class_c_scaled_correlation_b_b.html#af2c0f1585d931d93262e1a297b2a1001", null ],
    [ "GetTrialLength", "class_c_scaled_correlation_b_b.html#ac666d2d2f121426dead4aa4cfe36f691", null ],
    [ "ModifyAllParameters", "class_c_scaled_correlation_b_b.html#a5c7f28436792a9d61a596bc3464bbeb4", null ],
    [ "ModifyCorrelationWindow", "class_c_scaled_correlation_b_b.html#a3d2c09cae3a02aedcbfff81aeb92053d", null ],
    [ "ModifyScaleWindow", "class_c_scaled_correlation_b_b.html#ad0b463097bff348349659d57f98c854e", null ],
    [ "ModifyTrialLength", "class_c_scaled_correlation_b_b.html#abd196ac085451eb9ad45e5447a3bd8b9", null ]
];