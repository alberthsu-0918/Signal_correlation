var files =
[
    [ "Constants.h", "_constants_8h.html", "_constants_8h" ],
    [ "CorrelationLib.cpp", "_correlation_lib_8cpp.html", "_correlation_lib_8cpp" ],
    [ "CorrelationLib.h", "_correlation_lib_8h.html", "_correlation_lib_8h" ],
    [ "CrossCorrelation-BB.cpp", "_cross_correlation-_b_b_8cpp.html", "_cross_correlation-_b_b_8cpp" ],
    [ "CrossCorrelation-BB.h", "_cross_correlation-_b_b_8h.html", null ],
    [ "CrossCorrelation-BC.cpp", "_cross_correlation-_b_c_8cpp.html", "_cross_correlation-_b_c_8cpp" ],
    [ "CrossCorrelation-BC.h", "_cross_correlation-_b_c_8h.html", null ],
    [ "CrossCorrelation-CC.cpp", "_cross_correlation-_c_c_8cpp.html", "_cross_correlation-_c_c_8cpp" ],
    [ "CrossCorrelation-CC.h", "_cross_correlation-_c_c_8h.html", null ],
    [ "MyMath.cpp", "_my_math_8cpp.html", null ],
    [ "MyMath.h", "_my_math_8h.html", "_my_math_8h" ],
    [ "ScaledCorrelation-BB.cpp", "_scaled_correlation-_b_b_8cpp.html", "_scaled_correlation-_b_b_8cpp" ],
    [ "ScaledCorrelation-BB.h", "_scaled_correlation-_b_b_8h.html", "_scaled_correlation-_b_b_8h" ],
    [ "ScaledCorrelation-BC.cpp", "_scaled_correlation-_b_c_8cpp.html", "_scaled_correlation-_b_c_8cpp" ],
    [ "ScaledCorrelation-BC.h", "_scaled_correlation-_b_c_8h.html", "_scaled_correlation-_b_c_8h" ],
    [ "ScaledCorrelation-CC.cpp", "_scaled_correlation-_c_c_8cpp.html", "_scaled_correlation-_c_c_8cpp" ],
    [ "ScaledCorrelation-CC.h", "_scaled_correlation-_c_c_8h.html", "_scaled_correlation-_c_c_8h" ],
    [ "StdAfx.cpp", "_std_afx_8cpp.html", null ],
    [ "StdAfx.h", "_std_afx_8h.html", "_std_afx_8h" ]
];