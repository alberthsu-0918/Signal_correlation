var class_c_cross_correlation_b_b =
[
    [ "CCrossCorrelationBB", "class_c_cross_correlation_b_b.html#acd7c4b0634b5e9cad584f3944fe15198", null ],
    [ "~CCrossCorrelationBB", "class_c_cross_correlation_b_b.html#a97e5118e981d899100d65e0f8e4f9754", null ],
    [ "ComputeCrossCorrelation", "class_c_cross_correlation_b_b.html#a6ee7d5fd157c9f18f403764232679a7c", null ],
    [ "ComputeWindowedCrossCorrelationPerTrial", "class_c_cross_correlation_b_b.html#a381276e825f9d09bb374f9479f313219", null ],
    [ "GetCorrelationWindow", "class_c_cross_correlation_b_b.html#a96e6488b808dfc1af0bc7705f9465e42", null ],
    [ "GetCrossCorrelogram", "class_c_cross_correlation_b_b.html#a190b44e0d9bd8f44a4c22e4a91c4b9f7", null ],
    [ "GetTrialLength", "class_c_cross_correlation_b_b.html#af35d07ba17ebd3b4a6d443ec5d8b833b", null ],
    [ "ModifyAllParameters", "class_c_cross_correlation_b_b.html#ae5d4cb618d0a98a29d20d4e6ef6027ff", null ],
    [ "ModifyCorrelationWindow", "class_c_cross_correlation_b_b.html#a4389bf28c6131e64f1ee0a6602503036", null ],
    [ "ModifyTrialLength", "class_c_cross_correlation_b_b.html#a083167afb31fbebcdbd8f1ad6c6ce39d", null ]
];