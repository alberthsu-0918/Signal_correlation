var class_c_scaled_correlation_b_c =
[
    [ "CScaledCorrelationBC", "class_c_scaled_correlation_b_c.html#a0cbbe8df2e517aff0a6ccbee4a51e9ed", null ],
    [ "~CScaledCorrelationBC", "class_c_scaled_correlation_b_c.html#a8cd3e0c8e4613f7ca6bc8249b846627b", null ],
    [ "ComputeScaledCorrelation", "class_c_scaled_correlation_b_c.html#ac35f07200d00674dd546872ba829c728", null ],
    [ "GetCorrelationWindow", "class_c_scaled_correlation_b_c.html#acf6d63afd5aef0b8ab9985224ba9a76a", null ],
    [ "GetDistributionOfCorrelationCoefficients", "class_c_scaled_correlation_b_c.html#aec265d0c785214f0f8c3a43e71986590", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinNr", "class_c_scaled_correlation_b_c.html#a287ad3768be5517f8e17c3d03d5fe58b", null ],
    [ "GetDistributionOfCorrelationCoefficientsBinSize", "class_c_scaled_correlation_b_c.html#a5a835a8468caf2c39f7c78e02984d8db", null ],
    [ "GetPBsCoefficientCounts", "class_c_scaled_correlation_b_c.html#aa7c9381f9de0b3c869b813ed92c9f9d6", null ],
    [ "GetPBsCoefficientSums", "class_c_scaled_correlation_b_c.html#a2ae83e6d5731be7e080c152f11d89345", null ],
    [ "GetScaledCrossCorrelogram", "class_c_scaled_correlation_b_c.html#a5b0b343be139e630ffc29d71d40efda8", null ],
    [ "GetScaleWindow", "class_c_scaled_correlation_b_c.html#afcf5b92e1b4d74c07355d455e7815bc2", null ],
    [ "GetTrialLength", "class_c_scaled_correlation_b_c.html#a96d61f87c4ff4c0324855655deed6dcc", null ],
    [ "ModifyAllParameters", "class_c_scaled_correlation_b_c.html#aa7492385665005229f53569221e4660c", null ],
    [ "ModifyCorrelationWindow", "class_c_scaled_correlation_b_c.html#a5c65e2a07d13b0b0b8b574373497c70d", null ],
    [ "ModifyScaleWindow", "class_c_scaled_correlation_b_c.html#aa316c50aa4492cd074110b98a1ef66f4", null ],
    [ "ModifyTrialLength", "class_c_scaled_correlation_b_c.html#ad28c76ff3c18ae18c5b5751014aa701e", null ]
];