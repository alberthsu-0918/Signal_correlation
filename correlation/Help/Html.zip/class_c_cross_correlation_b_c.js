var class_c_cross_correlation_b_c =
[
    [ "CCrossCorrelationBC", "class_c_cross_correlation_b_c.html#a928346da7e3e0554f0fccb8cd197a6d0", null ],
    [ "~CCrossCorrelationBC", "class_c_cross_correlation_b_c.html#a5e193951aaa70a5b852d571bd1b4bba6", null ],
    [ "ComputeCrossCorrelation", "class_c_cross_correlation_b_c.html#a1683da50f4008c771be85c8130fb5c5c", null ],
    [ "GetCorrelationWindow", "class_c_cross_correlation_b_c.html#a443c655a2e267abb61296461cec3ce0c", null ],
    [ "GetCrossCorrelogram", "class_c_cross_correlation_b_c.html#a17ab76fe3cdd7112b7b4b0a325a600b3", null ],
    [ "GetTrialLength", "class_c_cross_correlation_b_c.html#ad641d844f959528afdd8aa1758059922", null ],
    [ "ModifyAllParameters", "class_c_cross_correlation_b_c.html#af75f9856237690dd1a098f8d4c8601d3", null ],
    [ "ModifyCorrelationWindow", "class_c_cross_correlation_b_c.html#a74c8ad7310275d5c58f442071e546154", null ],
    [ "ModifyTrialLength", "class_c_cross_correlation_b_c.html#ac1142b460349513d0afc21819cd415a7", null ]
];