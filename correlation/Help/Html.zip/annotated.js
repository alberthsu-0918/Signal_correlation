var annotated =
[
    [ "CCrossCorrelationBB", "class_c_cross_correlation_b_b.html", "class_c_cross_correlation_b_b" ],
    [ "CCrossCorrelationBC", "class_c_cross_correlation_b_c.html", "class_c_cross_correlation_b_c" ],
    [ "CCrossCorrelationCC", "class_c_cross_correlation_c_c.html", "class_c_cross_correlation_c_c" ],
    [ "CScaledCorrelationBB", "class_c_scaled_correlation_b_b.html", "class_c_scaled_correlation_b_b" ],
    [ "CScaledCorrelationBC", "class_c_scaled_correlation_b_c.html", "class_c_scaled_correlation_b_c" ],
    [ "CScaledCorrelationCC", "class_c_scaled_correlation_c_c.html", "class_c_scaled_correlation_c_c" ]
];