
#ifndef CORRELATIONLIB_H
#define CORRELATIONLIB_H

#ifdef CORRELATIONLIB_EXPORTS
#define CORRELATIONLIB_API __declspec(dllexport)
#else
#define CORRELATIONLIB_API __declspec(dllimport)
#endif

#endif